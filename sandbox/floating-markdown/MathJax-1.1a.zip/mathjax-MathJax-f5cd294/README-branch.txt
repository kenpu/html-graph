This is release branch v1.1 of MathJax.
